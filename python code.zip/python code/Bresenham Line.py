import matplotlib.pyplot as plt

# Starting and ending coordinates
x0, y0 = 9, 18
xn, yn = 14, 22

# Calculate differences
dx = xn - x0
dy = yn - y0

# Initial decision parameter
p = 2 * dy - dx

# Starting point
x, y = x0, y0

# Lists for plotting
x_points = [x]
y_points = [y]

# Table header
print("Pk\tPk+1\tXk\tYk")

# Print initial point
print(f"{p}\t-\t{x}\t{y}")

# Loop for Bresenham algorithm
for i in range(dx):
    pk = p  # current decision parameter

    if p >= 0:
        x += 1
        y += 1
        p = p + 2 * dy - 2 * dx
    else:
        x += 1
        p = p + 2 * dy

    pk1 = p  # next decision parameter after update

    # Print values
    print(f"{pk}\t{pk1}\t{x}\t{y}")

    # Store points
    x_points.append(x)
    y_points.append(y)

# Plot result
plt.plot(x_points, y_points, marker='o', linestyle='-')
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.title("Bresenham Line Drawing Algorithm")
plt.grid(True)
plt.show()