x1,y1 = 2,3
x2,y2 = 10,8

dx = x2-x1
dy = y2-y1

steps = max(abs(dx),abs(dy))

x_inc = dx/steps
y_inc = dy/steps

x = x1
y = y1

x_points =[]
y_points =[]