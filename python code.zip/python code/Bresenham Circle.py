import matplotlib.pyplot as plt

# Input
xc = int(input("Enter center xc: "))
yc = int(input("Enter center yc: "))
r  = int(input("Enter radius r: "))

x = 0
y = r
d = 3 - 2 * r

x_points = []
y_points = []

def add_symmetric_points(xc, yc, x, y):
    pts = [
        (xc + x, yc + y),
        (xc - x, yc + y),
        (xc + x, yc - y),
        (xc - x, yc - y),
        (xc + y, yc + x),
        (xc - y, yc + x),
        (xc + y, yc - x),
        (xc - y, yc - x),
    ]
    return pts

step = 0
print("\nStep x\t y\t d\t 8-way Points")

while x <= y:
    points = add_symmetric_points(xc, yc, x, y)

    # store points
    for (px, py) in points:
        x_points.append(px)
        y_points.append(py)

    # print step info
    print(f"{step}\t {x}\t {y}\t {d}\t {points}")

    # decision update
    if d < 0:
        d = d + 4 * x + 6
    else:
        d = d + 4 * (x - y) + 10
        y = y - 1

    x = x + 1
    step += 1

# remove duplicates (optional but clean)
unique_pts = list(set(zip(x_points, y_points)))
x_points = [p[0] for p in unique_pts]
y_points = [p[1] for p in unique_pts]

# plot border points
plt.scatter(x_points, y_points, color="red", s=8)
plt.title("Bresenham’s Circle Drawing Algorithm")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid(True)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()