import numpy as np
import matplotlib.pyplot as plt

# Clipping Window
xmin, xmax = 30, 70
ymin, ymax = 30, 70

# Generate Curve
x = np.linspace(0, 100, 1000)
y = 50 + 30 * np.sin(0.1 * x)

# Separate Exterior and Interior
x_exterior, y_exterior = [], []
x_interior, y_interior = [], []

for i in range(len(x)):
    if xmin <= x[i] <= xmax and ymin <= y[i] <= ymax:
        x_interior.append(x[i])
        y_interior.append(y[i])
    else:
        x_exterior.append(x[i])
        y_exterior.append(y[i])

plt.figure()

# Draw Clipping Window
plt.plot([xmin, xmax, xmax, xmin, xmin],
         [ymin, ymin, ymax, ymax, ymin], linewidth=2, label="Clipping Window")

# Original Curve (light)
plt.plot(x, y, linestyle='--', alpha=0.3, label="Original Curve")

# Exterior (Visible Part)
plt.plot(x_exterior, y_exterior, linewidth=2, label="Exterior Visible Part")

# Removed Interior
plt.plot(x_interior, y_interior, linestyle=':', label="Removed Interior Part")

plt.text(40, 50, "Interior Removed")
plt.text(10, 85, "Exterior Region")

plt.gca().set_aspect('equal', adjustable='box')
plt.title("Exterior Clipping with Indicated Parts")
plt.xlabel("X")
plt.ylabel("Y")
plt.legend()
plt.grid(True)
plt.show()