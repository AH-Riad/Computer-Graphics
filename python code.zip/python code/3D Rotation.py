import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# User Input
Xold = float(input("Enter Xold: "))
Yold = float(input("Enter Yold: "))
Zold = float(input("Enter Zold: "))

theta_degree = float(input("Enter Rotation Angle (in degrees): "))

# Convert angle to radians
theta = math.radians(theta_degree)

# Rotation Formula (X-axis Rotation)
Xnew = Xold
Ynew = Yold * math.cos(theta) - Zold * math.sin(theta)
Znew = Yold * math.sin(theta) + Zold * math.cos(theta)

# Print Results
print("\nInitial Coordinates:", (Xold, Yold, Zold))
print("Rotation Angle:", theta_degree, "degrees")
print("New Coordinates after Rotation:", (round(Xnew, 3), round(Ynew, 3), round(Znew, 3)))

# Plot Figure
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Original Point
ax.scatter(Xold, Yold, Zold)
ax.text(Xold, Yold, Zold, " Original Point")

# Rotated Point
ax.scatter(Xnew, Ynew, Znew)
ax.text(Xnew, Ynew, Znew, " Rotated Point")

# Line connecting points
ax.plot([Xold, Xnew], [Yold, Ynew], [Zold, Znew])

# Labels and Title
ax.set_xlabel("X Axis")
ax.set_ylabel("Y Axis")
ax.set_zlabel("Z Axis")
ax.set_title("3D Rotation about X-axis")

plt.show()