import matplotlib.pyplot as plt

# Input point
x = float(input("Enter X: "))
y = float(input("Enter Y: "))

# Scaling factors
Sx = float(input("Enter Sx: "))
Sy = float(input("Enter Sy: "))

# Scaling formula
x_new = x * Sx
y_new = y * Sy

# Output
print("Original Point:", (x, y))
print("Scaled Point:", (x_new, y_new))

# Plot
plt.scatter(x, y)
plt.scatter(x_new, y_new)

plt.plot([0, x], [0, y])
plt.plot([0, x_new], [0, y_new])

plt.title("2D Scaling of a Point")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

plt.grid()
plt.show()