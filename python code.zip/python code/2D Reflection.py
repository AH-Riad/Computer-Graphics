import matplotlib.pyplot as plt

# Point input
x = int(input("Enter X: "))
y = int(input("Enter Y: "))

print("1. Reflection about X-axis")
print("2. Reflection about Y-axis")

choice = int(input("Enter choice: "))

# -------- Reflection --------
if choice == 1:
    x_new = x
    y_new = -y

elif choice == 2:
    x_new = -x
    y_new = y

else:
    print("Invalid choice")
    exit()

# Output
print("Original Point:", (x, y))
print("New Point:", (x_new, y_new))

# Plot
plt.scatter(x, y)
plt.scatter(x_new, y_new)

plt.plot([0, x], [0, y])
plt.plot([0, x_new], [0, y_new])

plt.title("2D Reflection of a Point")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

plt.grid()
plt.show()