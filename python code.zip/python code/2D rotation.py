import matplotlib.pyplot as plt
import math

# Point
x, y = 4, 3

# Angle
theta = math.radians(45)

# Rotation
x_new = x * math.cos(theta) - y * math.sin(theta)
y_new = x * math.sin(theta) + y * math.cos(theta)

# Output
print("Old Point:", (x, y))
print("New Point:", (round(x_new, 2), round(y_new, 2)))

# Plot
plt.plot(x, y, 'o') #plt.scatter(x, y)
plt.plot(x_new,y_new,'o') #plt.scatter(x_new, y_new)

plt.plot([0, x], [0, y])
plt.plot([0, x_new], [0, y_new])

plt.title("2D Rotation of a Point")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid()
plt.show()