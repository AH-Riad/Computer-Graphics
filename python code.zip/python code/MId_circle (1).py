import matplotlib.pyplot as plt

# taking input from the user
xc = int(input("Enter center xc: "))
yc = int(input("Enter center yc: "))
r = int(input("Enter radius r: "))

# initializing the starting point and decision parameter
x = 0
y = r
p = 1 - r

# creating lists to store the points
x_points = []
y_points = []


print("\nMidpoint Circle Generated Points:")
i = 0

while x <= y:
    # 8-way symmetry points
    points = [
        (xc + x, yc + y),
        (xc - x, yc + y),
        (xc + x, yc - y),
        (xc - x, yc - y),
        (xc + y, yc + x),
        (xc - y, yc + x),
        (xc + y, yc - x),
        (xc - y, yc - x),
    ]
    
    for (px, py) in points:
        x_points.append(px)
        y_points.append(py)
        print(f"P{i} = ({px}, {py})")
        i += 1

    x = x + 1
    if p < 0:
        p = p + 2 * x + 1
    else:
        y = y - 1
        p = p + 2 * x + 1 - 2 * y

plt.scatter(x_points, y_points, color='blue')
plt.title("Midpoint Circle Drawing Algorithm")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid(True)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()
