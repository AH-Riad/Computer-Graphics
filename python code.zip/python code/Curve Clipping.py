import numpy as np
import matplotlib.pyplot as plt

# Clipping Window
xmin, xmax = 20, 80
ymin, ymax = 20, 80

# Generate Circle
theta = np.linspace(0, 2*np.pi, 1000)
r = 40
xc, yc = 50, 50

x = xc + r * np.cos(theta)
y = yc + r * np.sin(theta)

# Separate Inside and Outside Points
x_inside, y_inside = [], []
x_outside, y_outside = [], []

for i in range(len(x)):
    if xmin <= x[i] <= xmax and ymin <= y[i] <= ymax:
        x_inside.append(x[i])
        y_inside.append(y[i])
    else:
        x_outside.append(x[i])
        y_outside.append(y[i])

plt.figure()

# Draw Clipping Window
plt.plot([xmin, xmax, xmax, xmin, xmin],
         [ymin, ymin, ymax, ymax, ymin], linewidth=2, label="Clipping Window")

# Original Curve (light dashed)
plt.plot(x, y, linestyle='--', alpha=0.3, label="Original Curve")

# Visible (Inside) Curve
plt.plot(x_inside, y_inside, linewidth=2, label="Visible (Clipped) Part")

# Rejected (Outside) Curve
plt.plot(x_outside, y_outside, linestyle=':', label="Rejected Part")

plt.text(25, 85, "Outside Region")
plt.text(45, 50, "Inside Region")

plt.gca().set_aspect('equal', adjustable='box')
plt.title("Curve Clipping with Indicated Regions")
plt.xlabel("X")
plt.ylabel("Y")
plt.legend()
plt.grid(True)
plt.show()