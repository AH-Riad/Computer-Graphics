# 3D Reflection in Computer Graphics (Reflection about XY Plane)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# User Input
Xold = float(input("Enter Xold: "))
Yold = float(input("Enter Yold: "))
Zold = float(input("Enter Zold: "))

# Reflection Formula (About XY Plane)
Xnew = Xold
Ynew = Yold
Znew = -Zold

# Output
print("\nInitial Coordinates:", (Xold, Yold, Zold))
print("Reflected Coordinates (about XY plane):", (Xnew, Ynew, Znew))

# Plot Figure
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Original Point
ax.scatter(Xold, Yold, Zold)
ax.text(Xold, Yold, Zold, " Original Point")

# Reflected Point
ax.scatter(Xnew, Ynew, Znew)
ax.text(Xnew, Ynew, Znew, " Reflected Point")

# Line connecting points
ax.plot([Xold, Xnew], [Yold, Ynew], [Zold, Znew])

ax.set_xlabel("X Axis")
ax.set_ylabel("Y Axis")
ax.set_zlabel("Z Axis")
ax.set_title("3D Reflection about XY Plane")

plt.show()