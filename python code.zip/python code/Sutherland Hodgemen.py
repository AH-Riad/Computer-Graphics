import matplotlib.pyplot as plt

# Original Polygon
polygon = [(25, 30), (40, 45), (55, 30), (40, 15)]

# Clipping Window
xmin, xmax = 30, 50
ymin, ymax = 20, 40


def inside(point, edge):
    x, y = point
    if edge == "left":
        return x >= xmin
    elif edge == "right":
        return x <= xmax
    elif edge == "bottom":
        return y >= ymin
    elif edge == "top":
        return y <= ymax


def intersection(p1, p2, edge):
    x1, y1 = p1
    x2, y2 = p2

    if x1 != x2:
        m = (y2 - y1) / (x2 - x1)
    else:
        m = None

    if edge == "left":
        x = xmin
        y = y1 + (xmin - x1) * m
    elif edge == "right":
        x = xmax
        y = y1 + (xmax - x1) * m
    elif edge == "bottom":
        y = ymin
        if m is not None:
            x = x1 + (ymin - y1) / m
        else:
            x = x1
    elif edge == "top":
        y = ymax
        if m is not None:
            x = x1 + (ymax - y1) / m
        else:
            x = x1

    return (round(x, 2), round(y, 2))


def clip_polygon(polygon, edge):
    clipped = []
    for i in range(len(polygon)):
        current = polygon[i]
        prev = polygon[i - 1]

        if inside(current, edge):
            if inside(prev, edge):
                clipped.append(current)
            else:
                clipped.append(intersection(prev, current, edge))
                clipped.append(current)
        elif inside(prev, edge):
            clipped.append(intersection(prev, current, edge))
    return clipped


def plot_stage(poly, title):
    plt.figure()
    window_x = [xmin, xmax, xmax, xmin, xmin]
    window_y = [ymin, ymin, ymax, ymax, ymin]
    plt.plot(window_x, window_y)

    x = [p[0] for p in poly] + [poly[0][0]]
    y = [p[1] for p in poly] + [poly[0][1]]
    plt.plot(x, y, marker='o')

    plt.gca().set_aspect('equal', adjustable='box')
    plt.title(title)
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.grid(True)
    plt.show()


# Step 0: Original Polygon
plot_stage(polygon, "Original Polygon")

# Step 1: Left Clipping
poly_left = clip_polygon(polygon, "left")
plot_stage(poly_left, "After Left Clipping")

# Step 2: Right Clipping
poly_right = clip_polygon(poly_left, "right")
plot_stage(poly_right, "After Right Clipping")

# Step 3: Top Clipping
poly_top = clip_polygon(poly_right, "top")
plot_stage(poly_top, "After Top Clipping")

# Step 4: Bottom Clipping (Final Result)
poly_bottom = clip_polygon(poly_top, "bottom")
plot_stage(poly_bottom, "After Bottom Clipping (Final Polygon)")