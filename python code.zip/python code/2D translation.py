import matplotlib.pyplot as plt

# Input
x, y = map(float, input("Enter (x y): ").split())
tx, ty = map(float, input("Enter (Tx Ty): ").split())

# Translation
x_new = x + tx
y_new = y + ty

# Output
print("\nOriginal :", (x,y))
print("Translated:", (x_new, y_new))

# Plot
plt.scatter([x, x_new], [y, y_new])
plt.arrow(x, y, tx, ty)

plt.text(x, y, "O")
plt.text(x_new, y_new, "O'")

plt.title("2D Translation")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

plt.grid()
plt.show()