# 3D Scaling in Computer Graphics

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# User Input
Xold = float(input("Enter Xold: "))
Yold = float(input("Enter Yold: "))
Zold = float(input("Enter Zold: "))

Sx = float(input("Enter Scaling Factor Sx: "))
Sy = float(input("Enter Scaling Factor Sy: "))
Sz = float(input("Enter Scaling Factor Sz: "))

# Scaling Formula
Xnew = Xold * Sx
Ynew = Yold * Sy
Znew = Zold * Sz

# Output
print("\nInitial Coordinates:", (Xold, Yold, Zold))
print("Scaling Factors:", (Sx, Sy, Sz))
print("New Coordinates after Scaling:", (Xnew, Ynew, Znew))

# Plot Figure
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Original Point
ax.scatter(Xold, Yold, Zold)
ax.text(Xold, Yold, Zold, " Original Point")

# Scaled Point
ax.scatter(Xnew, Ynew, Znew)
ax.text(Xnew, Ynew, Znew, " Scaled Point")

# Line connecting points
ax.plot([Xold, Xnew], [Yold, Ynew], [Zold, Znew])

# Labels
ax.set_xlabel("X Axis")
ax.set_ylabel("Y Axis")
ax.set_zlabel("Z Axis")
ax.set_title("3D Scaling")

plt.show()