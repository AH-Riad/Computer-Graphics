import matplotlib.pyplot as plt

# Input
xc = int(input("Enter center xc: "))
yc = int(input("Enter center yc: "))
r  = int(input("Enter radius r: "))

x = 0
y = r
p = 1 - r

x_points = []
y_points = []

def plot_circle_points(xc, yc, x, y):
    pts = [
        (xc + x, yc + y),
        (xc - x, yc + y),
        (xc + x, yc - y),
        (xc - x, yc - y),
        (xc + y, yc + x),
        (xc - y, yc + x),
        (xc + y, yc - x),
        (xc - y, yc - x),
    ]
    return pts

step = 0
print("\nStep x\t y\t p\t 8-way Points")

while x <= y:
    points = plot_circle_points(xc, yc, x, y)

    # store points for plotting
    for (px, py) in points:
        x_points.append(px)
        y_points.append(py)

    # print step details
    print(f"{step}\t {x}\t {y}\t {p}\t {points}")

    # update decision parameter
    x = x + 1
    if p < 0:
        p = p + 2*x + 1
    else:
        y = y - 1
        p = p + 2*x + 1 - 2*y

    step += 1

# Plot ONLY border points (NO connecting lines)
plt.scatter(x_points, y_points, color="red", s=5)

plt.title("Midpoint Circle Drawing Algorithm")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid(True)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()