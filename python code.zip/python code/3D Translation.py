# 3D Translation in Computer Graphics (Without Function)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# -------- User Input --------
Xold = float(input("Enter Xold: "))
Yold = float(input("Enter Yold: "))
Zold = float(input("Enter Zold: "))

Tx = float(input("Enter Tx (Translation in X): "))
Ty = float(input("Enter Ty (Translation in Y): "))
Tz = float(input("Enter Tz (Translation in Z): "))

# -------- Perform Translation --------
Xnew = Xold + Tx
Ynew = Yold + Ty
Znew = Zold + Tz

# -------- Print Results --------
print("\nInitial Coordinates (Xold, Yold, Zold):", (Xold, Yold, Zold))
print("Translation Vector (Tx, Ty, Tz):", (Tx, Ty, Tz))
print("New Coordinates (Xnew, Ynew, Znew):", (Xnew, Ynew, Znew))

# -------- Plotting --------
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot original point
ax.scatter(Xold, Yold, Zold)
ax.text(Xold, Yold, Zold, " Original Point")

# Plot translated point
ax.scatter(Xnew, Ynew, Znew)
ax.text(Xnew, Ynew, Znew, " Translated Point")

# Draw translation line
ax.plot([Xold, Xnew], [Yold, Ynew], [Zold, Znew])

# Labels and Title
ax.set_xlabel("X Axis")
ax.set_ylabel("Y Axis")
ax.set_zlabel("Z Axis")
ax.set_title("3D Translation of a Point")

plt.show()