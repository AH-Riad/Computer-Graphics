import matplotlib.pyplot as plt

# Original Point
#x, y = 3, 4

# Shearing factors
#shx, shy = 1, 0.5

# Point input
x = int(input("Enter X: "))
y = int(input("Enter Y: "))

# Shearing factors
shx = float(input("Enter Shx: "))
shy = float(input("Enter Shy: "))

print("1. Shear in X-axis")
print("2. Shear in Y-axis")

choice = int(input("Enter choice: "))

# Apply shearing
if choice == 1:
    x_new = x + shx * y
    y_new = y
    direction = "X-direction"
elif choice == 2:
    x_new = x
    y_new = y + shy * x
    direction = "Y-direction"
else:
    print("Invalid choice")
    exit()

# Output
#print(f"Shearing in {direction}")
#print(f"Original: ({x}, {y})")
#print(f"Sheared : ({round(x_new,2)}, {round(y_new,2)})")

print("Original:", (x,y))
print("Sheared :", (round(x_new,2),round(y_new,2)))

# Plot
plt.scatter([x, x_new], [y, y_new])
plt.plot([0, x], [0, y])
plt.plot([0, x_new], [0, y_new])

plt.text(x, y, "O")
plt.text(x_new, y_new, "O'")

plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.title("2D Shearing")

plt.grid()
plt.show()