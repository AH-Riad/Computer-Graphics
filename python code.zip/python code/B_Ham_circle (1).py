import matplotlib.pyplot as plt

# Input
xc = int(input("Enter center xc: "))
yc = int(input("Enter center yc: "))
r = int(input("Enter radius r: "))

# Initialization
x = 0
y = r
d = 3 - 2 * r

x_points = []
y_points = []

print("\nBresenham Circle Generated Points:")
i = 0

while x <= y:
    # 8-way symmetry points
    points = [
        (xc + x, yc + y),
        (xc - x, yc + y),
        (xc + x, yc - y),
        (xc - x, yc - y),
        (xc + y, yc + x),
        (xc - y, yc + x),
        (xc + y, yc - x),
        (xc - y, yc - x),
    ]
    
    for (px, py) in points:
        x_points.append(px)
        y_points.append(py)
        print(f"P{i} = ({px}, {py})")
        i += 1

    if d < 0:
        d = d + 4 * x + 6
    else:
        d = d + 4 * (x - y) + 10
        y = y - 1
    x = x + 1

# Plotting
plt.scatter(x_points, y_points, color='red')
plt.title("Bresenham Circle Drawing Algorithm")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid(True)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()
