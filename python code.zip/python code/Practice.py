import matplotlib.pyplot as plt

x=int(input("Enter X:"))
y=int(input("Enter Y:"))

Tx=int(input("Enter Translation vector Tx:"))
Ty=int(input("Enter Translation vector Ty:"))

Xn=x+Tx
Yn=y+Ty

print("Old value:",(x,y))
print("New value:",(Xn,Yn))

plt.plot(x,y,'o')
plt.plot(Xn,Yn,'o')

plt.plot([0,x],[0,y])
plt.plot([0,Xn],[0,Yn])

plt.title("2D translation")
plt.xlabel("X axis")
plt.ylabel("Y axis")

plt.grid()
plt.show()
