# 3D Shearing in Computer Graphics (Shearing in X Axis)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# User Input
Xold = float(input("Enter Xold: "))
Yold = float(input("Enter Yold: "))
Zold = float(input("Enter Zold: "))

Shy = float(input("Enter Shearing Parameter Shy (along Y): "))
Shz = float(input("Enter Shearing Parameter Shz (along Z): "))

# Shearing Formula (X-axis Shearing)
Xnew = Xold
Ynew = Yold + Shy * Xold
Znew = Zold + Shz * Xold

# Output
print("\nInitial Coordinates:", (Xold, Yold, Zold))
print("Shearing Parameters (Shy, Shz):", (Shy, Shz))
print("New Coordinates after Shearing:", (Xnew, Ynew, Znew))

# Plot Figure
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Original Point
ax.scatter(Xold, Yold, Zold)
ax.text(Xold, Yold, Zold, " Original Point")

# Sheared Point
ax.scatter(Xnew, Ynew, Znew)
ax.text(Xnew, Ynew, Znew, " Sheared Point")

# Line connecting points
ax.plot([Xold, Xnew], [Yold, Ynew], [Zold, Znew])

ax.set_xlabel("X Axis")
ax.set_ylabel("Y Axis")
ax.set_zlabel("Z Axis")
ax.set_title("3D Shearing in X-axis")

plt.show()